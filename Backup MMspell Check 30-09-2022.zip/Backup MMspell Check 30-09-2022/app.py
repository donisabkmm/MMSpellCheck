from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
import MySQLdb.cursors
import pandas as pd
import os
import re
app = Flask(__name__)
word = 'static/files/word'
app.config['word'] = word
app.secret_key = 'Password!1'
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'db_mmspellcheck'

mysql = MySQL(app)


@app.route('/')
@app.route('/login', methods=['GET', 'POST'])
def login():
    msg = ''
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        username = request.form['username']
        password = request.form['password']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM tbl_login WHERE u_name = % s AND u_password = % s', (username, password,))
        account = cursor.fetchone()
        if account:
            session['loggedin'] = True
            session['id'] = account['u_id']
            session['username'] = account['u_name']
            msg = 'Logged in successfully !'
            return render_template('admin.html', msg=msg)
        else:
            msg = 'Incorrect username / password !'
    return render_template('index.html', msg=msg)

@app.route('/wordadmin', methods=['GET', 'POST'])
def wordadmin():
    if request.method == 'POST':
        return render_template('admin.html')
    return render_template('wordadmin.html')
@app.route('/spellcheck', methods=['GET', 'POST'])
def spellcheck():
    if request.method == 'POST':
        return render_template('admin.html')
    return render_template('spellcheck.html')
@app.route('/settings', methods=['GET', 'POST'])
def settings():
    if request.method == 'POST':
        return render_template('admin.html')
    return render_template('settings.html')
@app.route('/about', methods=['GET', 'POST'])
def about():
    if request.method == 'POST':
        return render_template('admin.html')
    return render_template('about.html')

@app.route('/admin', methods=['GET', 'POST'])
def admin():
    if request.method == 'POST':
        return render_template('admin.html')
    return render_template('admin.html')
@app.route('/uploadfile', methods=['GET', 'POST'])
def uploadfile():
    if request.method == 'POST':
        #name = request.form['dataname']
        uploaded_file = request.files['file']
        if uploaded_file.filename != '':
            file_path = os.path.join(app.config['word'], uploaded_file.filename)
            # set the file path
            uploaded_file.save(file_path)
            col_names = ['title', 'wstatus', 'desc', 'type']
            # Use Pandas to parse the CSV file
            csvData = pd.read_csv(file_path, names=col_names, header=None)
            # Loop through the Rows

            for i, row in csvData.iterrows():
                sql = "INSERT INTO `tbl_words` (`title`, `wstatus`, `desc`, `type`) VALUES (%s, %s, %s, %s)"
                value = (row['title'], row['wstatus'], row['desc'], row['type'])
                cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
                cursor.execute(sql, value,)
                mysql.connection.commit()
                print(i, row['title'], row['wstatus'], row['desc'], row['type'])
            return redirect(url_for('wordadmin'))
    return redirect(url_for('wordadmin'))

@app.route('/logout')
def logout():
    session.pop('loggedin', None)
    session.pop('id', None)
    session.pop('username', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run()
